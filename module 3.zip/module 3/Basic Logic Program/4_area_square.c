#include<stdio.h>
main()
{	
	
	float a;
	
	printf("\n\n\t Enter a value = ",a);
	scanf("%f",&a);
	a=a*2;
	
	printf("rea of Square= %f, ",a);
	
}
	
