#include<stdio.h>
main()
{	int a,b;
	a=10,b=20;
	printf("\n\n\t a=%d , b=%d",a,b);
	printf("\n\n\t a+b=%d",a+b);
	
	printf("\n\n\t a-b=%d",a-b);
	
	printf("\n\n\t a*b=%d",a*b);
	
	printf("\n\n\t a/b=%d",a/b);
	
	printf("\n\n\t a%b=%.2f",a%b);
		
	
}
