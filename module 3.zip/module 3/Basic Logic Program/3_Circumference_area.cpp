#include<stdio.h>
main()
{	
	int r=2;
	float pi=3.14,area;
	
	area=pi*r*r;
	printf("\n\n\t area of circle= %f ",area);
	
	
}
