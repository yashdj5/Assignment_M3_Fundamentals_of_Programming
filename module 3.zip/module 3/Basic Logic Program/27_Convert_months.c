#include <stdio.h>
main() 			
{
	
    int days,months;

   
    printf("Enter a days: ");
    scanf("%d", &days);
    
    months=days/30;
    printf("%d days is approximately %d months", days, months);
    
    
}
