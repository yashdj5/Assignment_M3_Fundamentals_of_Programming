#include<stdio.h>
main()
{
	char str[30]="sharda school"; 
	
	printf("\n\n\t String = %s", str); 
	
	printf("\n\n\t %c.%c", str[0], str[7]);
	
	
}
