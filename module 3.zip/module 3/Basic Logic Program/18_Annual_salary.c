#include<stdio.h>
main()
{	
	int salary;
	
	printf("\n\n\t Enter your Monthly salary:  ");
	scanf("%d",&salary);
	
	printf("\n\n\n\t Your anual salary is %d",12*salary);
}
