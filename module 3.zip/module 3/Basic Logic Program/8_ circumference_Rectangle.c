#include<stdio.h>
main()
{	
	float c,a;
		
	printf("\n\n\t enter any value : ");
	scanf("%f",&a);
	
	c=4*a;
	
	printf("\n\n\t  circumference of Rectangle: ",a,c);
	
}
