#include<stdio.h>
main()
{	
	float studant,apple;
	
	printf("\n\t enter a studant Numbar: ");
	scanf("%f",&studant);
	
	apple=5*studant;
	
	printf("\t Each studant numbar of appale:%.2f",apple);
}
