#include<stdio.h>
main()
{	
	printf("\n\n\tyash jain");
	printf("\n\n\t05/11/1994");
	printf("\n\n\tAge:30");
	printf("\n\nC/5 sudarshan aprtment,Ghatlodiya,Ahmedabad 810061");
}
