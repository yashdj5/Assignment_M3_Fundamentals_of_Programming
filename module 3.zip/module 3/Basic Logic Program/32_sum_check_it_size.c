#include<stdio.h>
main()
{
	int a,b,sum;
	
	printf("enter a:");
	scanf("%d",&a);
	
	printf("enter b:");
	scanf("%d",&b);
	
	sum=a+b;
	
	printf("sum :%d+%d=%d",a,b,sum);
	
}
