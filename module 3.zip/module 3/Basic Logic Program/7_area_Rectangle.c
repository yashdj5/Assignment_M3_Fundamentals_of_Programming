#include<stdio.h>
main()
{	
	float w,l,area;
	
	
	printf("\n\n\t enter any value W: "  );
	scanf("%f",&w);
	
	printf("\n\n\t enter any value L: "  );
	scanf("%f",&l);
	area=w*l;
	printf("\n\n\t Find area of Rectangle: %f " ,area);
			 
}
