#include<stdio.h>
main()
{
	char num;
	
	printf("\n\n\t enter any number: ");
	scanf("%c",&num);
	
	printf("\n\n\t ascii value %d",num);	
}
