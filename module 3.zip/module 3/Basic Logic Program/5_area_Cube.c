#include<stdio.h>
main()
{

	float a;
	printf("\n\n\t  Enter a value= ",a);
	scanf("%f", &a);
	
	a=6*a*2;
	printf("\n\n\f Area of Cube= %f", a);
	 }
