#include<stdio.h>
main()
{	
	float surfacearea,a;
	
	printf(" enter value a: ");
	scanf("%f",&a);
	
	surfacearea=4*a;
	printf("circumference of square formula:%f",surfacearea);
}
