//Abbreviation

#include<stdio.h>
main()
{
	char str[30]="United Kingdom";
	
	
	//printf("\n\n\t Enter any string : ");
	//scanf("%s",&str);
	
	printf("\n\n\t String = %s", str); 
	
	printf("\n\n\t %c.%c", str[0], str[7]);

}
