#include<stdio.h>
main()
{	
	int salary;
	float ins;
	
	
	printf("/n/n/t enter salary:  ");
	scanf("%d",&salary);
	
	ins=salary*10/100;
	
	printf("\n\n\t insurance premium based on salary %f",ins);
	
}
