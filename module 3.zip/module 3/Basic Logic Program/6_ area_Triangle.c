#include<stdio.h>
main()
{	float b,h,a;
	
	printf("\n\n\t enter any value for b= ");
	scanf("%f",&b);

	printf("\n\n\t enter any value for h= ");
	scanf("%f",&h);
	
	a=0.5*b*h;
	
	printf("\n\n\t  area of Triangle= %.2f ",a,b,h);

}
