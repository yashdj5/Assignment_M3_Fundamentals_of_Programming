#include<stdio.h>
main()
{	
	int a,b,c;
	int triangle;
	
	printf("\n\n\t Enter any value  ");
	scanf("%d",&a);
	printf("\n\n\t Enter any value  ");
	scanf("%d",&b);
	printf("\n\n\t Enter any value  ");
	scanf("%d",&c);
	
	triangle=a+b+c;
	
	printf("triangle= %d",triangle);
	 
}
