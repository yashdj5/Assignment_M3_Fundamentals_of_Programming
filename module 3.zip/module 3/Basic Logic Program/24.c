#include<stdio.h>
#include<stdlib.h>
main()
{	
	int s1,s2,s3,s4,s5;
	float average;
	char e1[10],e2[10],e3[10],e4[10],e5[10];
	
	printf("enter employee name:  ");
	scanf(" %s",&e1);
	
	printf("enter employee salary:  ");
	scanf("%d",&salary1);
	
	printf("enter employee name:  ");
	scanf(" %s",&e2);
	
	printf("enter employee salary:  ");
	scanf("%d",&salary2);
	

}
