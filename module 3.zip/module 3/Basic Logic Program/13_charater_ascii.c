#include<stdio.h>
main()
{
	char ch;
	
	printf("\n\n\t enter any charater: ");
	scanf("%c",&ch);
	
	printf("\n\n\t ascii value %d",ch);	
}
