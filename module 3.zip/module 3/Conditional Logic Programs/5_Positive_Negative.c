#include<stdio.h>
main()
{
	int a;
	
	printf("please enter any number ");
	scanf("%d",&a);
	
	if(a>0)
	printf("please  number is positive %d",a);
	else
	printf("please  number is negative %d",a);
}
