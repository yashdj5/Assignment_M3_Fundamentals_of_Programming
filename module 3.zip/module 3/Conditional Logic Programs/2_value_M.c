#include<stdio.h>
main()
{
	int m;
		
	printf("enter m: ");
	scanf("%d",&m);

	
	if(m>0)
	{	
		printf("the value of m is 1");
	}
	else if(m<0)
	{
		printf("the value of m is -1 ");	
	}
	else
	{	
		printf("the value of m is 0 ");
	}
}
