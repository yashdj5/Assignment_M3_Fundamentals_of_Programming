#include<stdio.h>
main()
{	
	char ch;
	printf("enter your charater: ");
	scanf("%c",&ch);
	switch(ch)
	{
		case 'a':("it is a vowel");
			break;
		case 'e':("it is a vowel");
			break;	
		case 'i':("it is a vowel");
			break;
		case 'o':("it is a vowel");
			break;
		case 'u':("it is a vowel");
			break;
		case 'A':("it is a vowel");
			break;
		case 'E':("it is a vowel");
			break;	
		case 'I':("it is a vowel");
			break;
		case 'O':("it is a vowel");
			break;
		case 'U':("it is a vowel");
			break;				
		default:	
			printf("it is a consonent ");
	}
}
