#include<stdio.h>
main()
{
	int a,b;
	
	printf("\nenter a:");
	scanf("%d",&a);
	printf("\nenter b:");
	scanf("%d",&b);
	
	if(a==b)
	{	
		printf("numbar %d and %d are equal ",a,b);
	}
	else
	{
		printf("numbar are not equal ");	
	}
}
