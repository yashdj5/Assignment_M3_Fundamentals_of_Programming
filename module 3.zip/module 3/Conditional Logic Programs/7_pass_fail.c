#include<stdio.h>
main()
{
	int i,n;
	
	printf("enter a marks : ");
	scanf("%d",&n);
	
	if(n>=40)
	{
		printf("result is pass");
	}
	else
	{
		printf("result is fail");
	}
}
