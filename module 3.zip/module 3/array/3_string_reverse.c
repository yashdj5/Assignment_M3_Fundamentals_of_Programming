#include<stdio.h>
#include<string.h>

main()
{
	char str[30];
	
	printf("\n\n\t enter name: ");
	gets(str);
	
	printf("your name is %s",strrev(str
	));
}
