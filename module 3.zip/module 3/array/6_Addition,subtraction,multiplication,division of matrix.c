//WAP to make addition, Subtraction and multiplication of two matrix using 2-D Array.
#include<stdio.h>
main()
{
    int m1[3][3],m2[3][3],m[3][3];

    m1[0][0]=2;
    m1[0][1]=2;
    m1[0][2]=2;
    m1[1][0]=2;
    m1[1][1]=2;
    m1[1][2]=2;
    m1[2][0]=2;
    m1[2][1]=2;
    m1[2][2]=2;
    m2[0][0]=2;
    m2[0][1]=2;
    m2[0][2]=2;
    m2[1][0]=2;
    m2[1][1]=2;
    m2[1][2]=2;
    m2[2][0]=2;
    m2[2][1]=2;
    m2[2][2]=2;


}
