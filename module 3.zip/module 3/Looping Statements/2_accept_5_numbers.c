#include<stdio.h>
main()
{
	int n1,n2,n3,n4,n5,i;
	

	
	printf("\n\t enter a number n: ");
	scanf("%d %d %d %d %d",&n1,&n2,&n3,&n4,&n5);
	
	printf("\n\tyour number is n1 :%d",n1);
	printf("\n\tyour number is n2 :%d",n2);	
	printf("\n\tyour number is n3 :%d",n3);	
	printf("\n\tyour number is n4 :%d",n4);	
	printf("\n\tyour number is n5 :%d",n5);		
}
