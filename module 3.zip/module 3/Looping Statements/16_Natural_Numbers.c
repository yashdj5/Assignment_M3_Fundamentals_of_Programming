#include<stdio.h>
main()
{
	int n,sum=0,i;
	
				printf("\n\t enter Natural Numbers: " );
		   		scanf("%d",&n);

		while(i<=n)
		{
			
    
	
			sum=sum+i;
			i++;		
		}			
			printf(" \n\n\t the number is %d",sum);

		
}
