#include<stdio.h>
main()
{
	int a;
	
	for(a=42;a<=50;a++)
	{
		printf("\t %d",a);
	}
}
