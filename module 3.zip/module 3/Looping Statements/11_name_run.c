#include<stdio.h>
main()
{
	int str[20],i;
	
	
	for(i=0;i<=5;i++)
	{
		printf("\n\tenter a name:  ");
		scanf("%s",&str[i]);
	}
	
}
