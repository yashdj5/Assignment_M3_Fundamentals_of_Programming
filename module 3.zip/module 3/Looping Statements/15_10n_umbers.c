#include<stdio.h>
main()
{
	int n,sum=0,i;
	

		while(i<=10)
		{
			printf("\n\t enter Factorial: " );
		scanf("%d",&n);
    
	
			sum=sum+n;
			i++;		
		}			
			printf(" \n\n\t the number is %d",sum);

		
}
