#include<stdio.h>
main()
{
	int i,n,sum;
	
		printf("enter a number : ");
		scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sum=sum+1;	
	}	printf("\n\n\t result: %d",sum);
}
