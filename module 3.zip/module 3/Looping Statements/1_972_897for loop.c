#include<stdio.h>
main()
{
	int i;
	
	for(i=972;i>=897;i--)
	{
		printf("\n\t value less %ld",i);
	}
}
